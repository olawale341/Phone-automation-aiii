# FloatMate Native (Android 10+)

This is a **native Android project source**, not a compiled APK. It includes a movable overlay bubble, a panel, voice dictation using Android's speech recognizer, and a user-initiated Accessibility Service with basic commands.

## Implemented basic commands
- `open WhatsApp` (matches an installed app's label)
- `tap Wi-Fi` (uses accessible labels on the current screen)
- `scroll down` / `scroll up`
- `back` / `home`
- `type hello` (only into a currently focused accessible editable field)

It intentionally does not perform hidden actions or bypass protected screens. Text entry can be risky; review what will be typed before using it.

## Easiest build path: cloud build
See `BUILD_WITH_CLOUD.txt`. The included GitHub Actions workflow (`.github/workflows/build-apk.yml`) builds a debug APK on a hosted runner, so Android Studio, Java, Gradle, and the Android SDK do not need to be installed on your phone. The APK is downloadable only after the workflow succeeds.

## Alternative: local build
- Android Studio with Android SDK Platform 35
- JDK 17
- Android Gradle Plugin 8.7.3 and Gradle 8.9

Open this folder in Android Studio, allow Gradle sync, then use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## First launch on the phone
1. Install the debug APK.
2. Open FloatMate AI.
3. Tap **Allow floating window**, then grant “Display over other apps”.
4. Tap **Enable Accessibility Service**. In Android Accessibility settings, enable **FloatMate phone control**.
5. Return to FloatMate and tap **Start floating assistant**.
6. The small FM bubble should remain above apps. Tap it to open the panel; drag it to move it.

## Limitations / safety
- This project source has not been compiled or tested on a physical Infinix Note 8i.
- The panel's current action executor handles basic deterministic commands. It does not yet translate arbitrary natural language into safe executable actions or connect the native overlay directly to the AI backend. Use the existing FloatMate AI web chat for advanced natural-language guidance.
- Android speech recognition may use an internet connection depending on the speech provider and device configuration.
- Some apps hide accessible labels or block automation in secure screens.
- Accessibility permission is powerful: enable it only if you understand and trust the app. Do not use it for unattended financial transactions, password/OTP capture, or bypassing security checks.
- The Android 10 target is supported by minSdk 26 and targetSdk 29. Modern Android Studio may suggest newer target SDKs; keep targetSdk 29 for this Android 10-focused first build.
