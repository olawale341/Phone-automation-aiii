package com.floatmate.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.view.ViewGroup
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val speechRequest = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(15, 18, 28))
        }
        val title = TextView(this).apply {
            text = "FloatMate AI"
            textSize = 28f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val intro = TextView(this).apply {
            text = "Native Android assistant • Android 10+\nGrant permissions below to enable the floating panel and accessibility actions."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, pad / 2, 0, pad)
        }
        status = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.rgb(170, 220, 190))
            setPadding(0, 0, 0, pad)
        }
        layout.addView(title)
        layout.addView(intro)
        layout.addView(status)
        addButton(layout, "1. Allow floating window") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "Overlay permission already enabled", Toast.LENGTH_SHORT).show()
        }
        addButton(layout, "2. Enable Accessibility Service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton(layout, "3. Start floating assistant") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow floating window permission first", Toast.LENGTH_LONG).show()
            } else {
                startService(Intent(this, FloatingAssistantService::class.java))
                Toast.makeText(this, "Floating assistant started", Toast.LENGTH_SHORT).show()
            }
        }
        addButton(layout, "Try voice input") {
            try {
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a phone command")
                startActivityForResult(i, speechRequest)
            } catch (_: Exception) {
                Toast.makeText(this, "Speech recognition is unavailable on this device", Toast.LENGTH_LONG).show()
            }
        }
        addButton(layout, "Open assistant website / AI chat") {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://floatmate-ai-agzzvv.v2.appdeploy.ai/")))
        }
        val note = TextView(this).apply {
            text = "\nPrivacy: Accessibility can expose text and controls from the current screen. Keep it enabled only if you trust this app. It does not bypass secure screens, CAPTCHAs or app permissions."
            textSize = 12f
            setTextColor(Color.rgb(170, 175, 195))
            setPadding(0, pad, 0, 0)
        }
        layout.addView(note)
        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = (7 * resources.displayMetrics.density).toInt()
        })
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            val overlay = Settings.canDrawOverlays(this)
            status.text = "Overlay permission: ${if (overlay) "enabled" else "not enabled"}\nAccessibility service: enable it in Android Accessibility settings."
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                PhoneAccessibilityService.instance?.handleCommand(words)
                    ?: Toast.makeText(this, "Start the floating assistant first, then try again.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
