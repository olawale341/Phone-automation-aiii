package com.floatmate.assistant

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Locale

class VoiceCaptureActivity : Activity() {
    private val requestCode = 55
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a phone command")
            startActivityForResult(i, requestCode)
        } catch (_: Exception) {
            Toast.makeText(this, "Speech recognition is unavailable", Toast.LENGTH_LONG).show()
            finish()
        }
    }
    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                val result = PhoneAccessibilityService.instance?.handleCommand(words) ?: "Enable the Accessibility Service first."
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }
}
