package com.floatmate.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class PhoneAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: PhoneAccessibilityService? = null }
    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }

    fun handleCommand(raw: String): String {
        val command = raw.trim()
        val lower = command.lowercase()
        return try {
            when {
                lower == "back" || lower == "go back" || lower == "press back" -> {
                    performGlobalAction(GLOBAL_ACTION_BACK); "Pressed Back."
                }
                lower == "home" || lower == "go home" -> {
                    performGlobalAction(GLOBAL_ACTION_HOME); "Went to Home."
                }
                lower.contains("scroll down") -> { scrollNode(rootInActiveWindow, forward = true); "Requested scroll down." }
                lower.contains("scroll up") -> { scrollNode(rootInActiveWindow, forward = false); "Requested scroll up." }
                lower.startsWith("open ") -> {
                    val appName = command.substringAfter("open ", "").trim()
                    openApp(appName)
                }
                lower.startsWith("tap ") || lower.startsWith("click ") || lower.startsWith("press ") -> {
                    val target = command.substringAfter(' ').trim()
                    if (target.isBlank()) "Say what text to tap."
                    else if (tapText(rootInActiveWindow, target)) "Tapped the accessible control matching “$target”."
                    else "I couldn't find an accessible control labelled “$target” on this screen."
                }
                lower.startsWith("type ") || lower.startsWith("enter text ") -> {
                    val text = if (lower.startsWith("type ")) command.substring(5) else command.substring(11)
                    val node = findFocusedEditable(rootInActiveWindow)
                    if (node == null) "No accessible text field is focused. Tap a text field first."
                    else {
                        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
                        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                        node.recycle()
                        if (ok) "Entered text in the focused field." else "This field does not allow accessibility text entry."
                    }
                }
                else -> "I can run basic commands: open [app name], tap [visible label], scroll down, scroll up, back, home, and type [text]. For natural-language AI planning, use the FloatMate AI chat."
            }
        } catch (e: Exception) {
            "That action could not be completed on this screen."
        }
    }

    private fun findFocusedEditable(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        if (root.isFocused && root.isEditable) return AccessibilityNodeInfo.obtain(root)
        for (i in 0 until root.childCount) {
            val found = findFocusedEditable(root.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun tapText(root: AccessibilityNodeInfo?, target: String): Boolean {
        if (root == null) return false
        val matches = root.findAccessibilityNodeInfosByText(target)
        for (node in matches) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable && current.isEnabled) {
                    val clicked = current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) return true
                }
                current = current.parent
            }
        }
        return false
    }

    private fun scrollNode(node: AccessibilityNodeInfo?, forward: Boolean): Boolean {
        if (node == null) return false
        if (node.isScrollable) {
            return node.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        }
        for (i in 0 until node.childCount) if (scrollNode(node.getChild(i), forward)) return true
        return false
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val matches = pm.getInstalledApplications(0).filter {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        }
        val app = matches.firstOrNull { pm.getLaunchIntentForPackage(it.packageName) != null }
            ?: return "I couldn't find an installed app matching “$name”."
        val intent: Intent = pm.getLaunchIntentForPackage(app.packageName) ?: return "This app cannot be opened directly."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return "Opening ${pm.getApplicationLabel(app)}."
    }
}
