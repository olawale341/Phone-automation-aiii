package com.floatmate.assistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class FloatingAssistantService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (bubble == null) createBubble()
        return START_STICKY
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun createBubble() {
        val density = resources.displayMetrics.density
        bubbleParams = WindowManager.LayoutParams(
            (54 * density).toInt(), (54 * density).toInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = (12 * density).toInt(); y = (170 * density).toInt() }
        val v = TextView(this).apply {
            text = "FM"
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                colors = intArrayOf(Color.rgb(130, 110, 255), Color.rgb(70, 82, 220))
            }
            elevation = 10 * density
        }
        var startX = 0f; var startY = 0f; var oldX = 0; var oldY = 0
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = e.rawX; startY = e.rawY; oldX = bubbleParams.x; oldY = bubbleParams.y; true }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - startX) < 8 && abs(e.rawY - startY) < 8) togglePanel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    bubbleParams.x = oldX + (startX - e.rawX).toInt()
                    bubbleParams.y = oldY + (e.rawY - startY).toInt()
                    try { wm.updateViewLayout(v, bubbleParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
        bubble = v
        wm.addView(v, bubbleParams)
    }

    private fun togglePanel() {
        if (panel != null) {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
        } else showPanel()
    }

    private fun showPanel() {
        val d = resources.displayMetrics.density
        panelParams = WindowManager.LayoutParams(
            (minOf(340, (resources.displayMetrics.widthPixels / d - 28).toInt()) * d).toInt(),
            (430 * d).toInt(), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER; softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14*d).toInt(), (12*d).toInt(), (14*d).toInt(), (12*d).toInt())
            background = GradientDrawable().apply {
                setColor(Color.rgb(20, 23, 35))
                cornerRadius = 20*d
                setStroke((1*d).toInt(), Color.rgb(67, 68, 100))
            }
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "FloatMate AI"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val close = Button(this).apply { text = "Hide"; isAllCaps = false; setOnClickListener { togglePanel() } }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f)); header.addView(close)
        root.addView(header)
        val help = TextView(this).apply {
            text = "Try: tap Wi-Fi, scroll down, go back, or open Settings"
            textSize = 11f; setTextColor(Color.LTGRAY); setPadding(0, (5*d).toInt(), 0, (8*d).toInt())
        }
        root.addView(help)
        val result = TextView(this).apply {
            text = "Ready. Commands act only when you send them."
            textSize = 12f; setTextColor(Color.rgb(196, 201, 223)); setPadding(0, 0, 0, (8*d).toInt())
        }
        root.addView(result)
        val input = EditText(this).apply {
            hint = "Enter a phone command…"
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(false)
            minLines = 2
            maxLines = 3
            background = GradientDrawable().apply { setColor(Color.rgb(34, 38, 54)); cornerRadius = 12*d; setStroke((1*d).toInt(), Color.DKGRAY) }
            setPadding((10*d).toInt(), (8*d).toInt(), (10*d).toInt(), (8*d).toInt())
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val run = Button(this).apply {
            text = "Run command"; isAllCaps = false
            setOnClickListener {
                val command = input.text.toString().trim()
                if (command.isEmpty()) { result.text = "Enter a command first."; return@setOnClickListener }
                val service = PhoneAccessibilityService.instance
                if (service == null) result.text = "Enable FloatMate phone control in Android Accessibility settings first."
                else result.text = service.handleCommand(command)
            }
        }
        val speak = Button(this).apply {
            text = "Speak"; isAllCaps = false
            setOnClickListener {
                val i = Intent(this@FloatingAssistantService, VoiceCaptureActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
        }
        actions.addView(run, LinearLayout.LayoutParams(0, -2, 1f)); actions.addView(speak)
        root.addView(actions)
        val caution = TextView(this).apply {
            text = "Review sensitive actions yourself. Protected screens may block automation."
            textSize = 10f; setTextColor(Color.rgb(173, 174, 195)); setPadding(0, (8*d).toInt(), 0, 0)
        }
        root.addView(caution)
        panel = root
        wm.addView(root, panelParams)
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null; panel = null
        super.onDestroy()
    }
}
